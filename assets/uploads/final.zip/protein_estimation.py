import pandas as pd
import numpy as np
from math import pi
from scipy import spatial


# Representation of the 3D space containing the protein
# It's a box
class BoundingBox:
    def __init__(self, df, radii):
        self.max_x = max(df.loc[:, 'x'].to_numpy() + radii)
        self.min_x = min(df.loc[:, 'x'].to_numpy() - radii)
        self.max_y = max(df.loc[:, 'y'].to_numpy() + radii)
        self.min_y = min(df.loc[:, 'y'].to_numpy() - radii)
        self.max_z = max(df.loc[:, 'z'].to_numpy() + radii)
        self.min_z = min(df.loc[:, 'z'].to_numpy() - radii)
        self.volume = (self.max_x - self.min_x) * (self.max_y - self.min_y) \
            * (self.max_z - self.min_z)

    def gen_points(self, N):
        """ Generates N number of random points in the space """
        xs = np.random.uniform(self.min_x, self.max_x, N)
        ys = np.random.uniform(self.min_y, self.max_y, N)
        zs = np.random.uniform(self.min_z, self.max_z, N)
        return np.transpose(np.array([xs, ys, zs]))

    def get_volume(self):
        """ Find the volume of the bounding box """
        return self.volume


class Protein:
    def __init__(self, atomfile, q=10, N=10000):
        self.df = self.load_data(atomfile)
        self.tree = self.make_tree()
        self.q = q  # neighbors to query
        self.N = N  # number of points to use for estimation
        self.radii = self.df.loc[:, 'radius'].to_numpy()
        self.bbox = BoundingBox(self.df, self.radii)

    # Public functions
    def get_volume(self):
        """ Returns the MC estimated volume and it's error estimate """
        randpts = self.bbox.gen_points(self.N)
        bbox_vol = self.bbox.get_volume()
        count, hits = self.hits_vol(randpts)
        f = count / len(randpts)
        est = f * bbox_vol
        err = bbox_vol * np.sqrt((f - f ** 2) / self.N)
        return est, err

    def get_area(self):
        """ Returns the MC estimated surface area and it's error estimate using our original shell method"""
        randpts = self.bbox.gen_points(self.N)
        bbox_vol = self.bbox.get_volume()
        epsilon = min(self.radii) / 25
        count, hits = self.hits_sa(randpts, epsilon)
        f = count / len(randpts)
        est = f * bbox_vol / epsilon
        err = bbox_vol * np.sqrt((f - f ** 2) / self.N) / epsilon  # Plus other estimation error
        return est, err

    def alt_get_area(self):
        """ Returns the MC estimated surface area and it's error estimate using our improved method"""
        rand_surface_points, sphere_indices = self.gen_surface_points()
        total_surface_area = self.sum_surface_areas()
        count, hits = self.alt_hits_sa(rand_surface_points, sphere_indices)
        f = count / len(rand_surface_points)
        est = f * total_surface_area
        err = total_surface_area * np.sqrt((f - f ** 2) / self.N)
        return est, err

    # Private functions
    # Determine if a point is in any of it's nearest atoms
    def in_atom(self, dists, inds):
        return any(dists <= [self.radii[x] for x in inds])

    # Returns a pair of values: the number of random points falling
    # within an atom, and the indices of those points in randpts
    def hits_vol(self, randpts):
        inds = []
        hits = []
        for i in range(len(randpts)):
            dists, inds = self.tree.query(randpts[i], self.q)
            if self.in_atom(dists, inds):
                hits.append(i)
        return len(hits), hits

    # Determine if a point is in the "shell" or on surface of any of the nearest atoms.
    # We position the shell with thickness epsilon, centered on the outer boundary of an
    # atom (based on radius)
    def in_outer_shell(self, dists, inds, epsilon):
        # Assume not in any shell until proven otherwise, if inside atom, definitely not on surface
        in_shell = False
        for index in range(len(dists)):
            radius_index = inds[index]
            if dists[index] < self.radii[radius_index] - epsilon / 2:
                return False
            if dists[index] < self.radii[radius_index] + epsilon / 2:
                in_shell = True
        return in_shell

    # Returns a pair of values: the number of random points falling
    # within an atom's "thin shell," and the indices of those points in randpts
    def hits_sa(self, randpts, epsilon):
        inds = []
        hits = []

        for i in range(len(randpts)):
            dists, inds = self.tree.query(randpts[i], self.q)
            if self.in_outer_shell(dists, inds, epsilon):
                hits.append(i)
        return len(hits), hits

    # Determine if points on the surface of an atom are within any other atoms
    def within_sphere(self, dists, distance_indices, current_sphere_index):
        # Compare each distance to the radii of every sphere except the one it is on the surface of
        for iter_index in range(len(dists)):
            if distance_indices[iter_index] == current_sphere_index:
                continue
            if dists[iter_index] < self.radii[iter_index]:
                return True
        return False

    # Returns a pair of values: the number of random points falling on surface, but
    # NOT within an atom, and the indices of those points in randpts
    def alt_hits_sa(self, randpts, sphere_indices):
        hits = []
        for i in range(len(randpts)):
            dists, distance_indices = self.tree.query(randpts[i], self.q)
            if not self.within_sphere(dists, distance_indices, sphere_indices[i]):
                hits.append(i)
        return len(hits), hits

    # Sum all atom's surface areas using formula for sphere
    def sum_surface_areas(self):
        return sum(4 * pi * self.radii ** 2)

    # Data Processing
    def load_data(self, f):
        return pd.read_csv(f, header=None, skiprows=[0],
                           names=['x', 'y', 'z', 'radius'],
                           delim_whitespace=True)

    def make_tree(self):
        return spatial.cKDTree((self.df.iloc[:, 0:3]).to_numpy())

    # Generate points randomly on the surface of any atom
    # (disregarding being inside other atoms)
    def gen_surface_points(self):
        # First pick a random sphere
        spheres = np.random.random_integers(0, len(self.radii) - 1, self.N)
        # Now pick N random thetas for longitude [0, pi)
        thetas = np.random.uniform(0, pi, self.N)
        # Pick N random phis for latitude [0, 2*pi)
        phis = np.random.uniform(0, 2 * pi, self.N)

        # Turn spherical coordinates into cartesian coordinates
        xs = self.df.iloc[spheres, 0].to_numpy() + self.radii[spheres] * np.sin(thetas) * np.cos(phis)
        ys = self.df.iloc[spheres, 1].to_numpy() + self.radii[spheres] * np.sin(thetas) * np.sin(phis)
        zs = self.df.iloc[spheres, 2].to_numpy() + self.radii[spheres] * np.cos(thetas)
        return np.transpose(np.array([xs, ys, zs])), spheres
