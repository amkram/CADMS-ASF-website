# ECS129 Final Project
## By Alexander Kramer, Kevin Lee and Alexander Miller

This project requires <strong> Python 3 </strong> and the following dependencies: `pandas`, `numpy`, `scipy`, `matplotlib`


The zip file contains 6 files, `run.py`, `protein_estimation.py`, `visualize.py`, `stats.py`, `report.pdf`, and this readme.

`run.py` is the interface to our project. Instructions for running it are below.

`visualize.py` and `protein_estimation.py` are used by `run.py` to perform the protein estimation methods and visualize the results.

`stats.py` is a program we used to generate plots.

### How to run

Example usage:

    python run.py -vaz -n <num random> -q <num query> -V <known volume> -A <known surface area> -f <filepath>
- `-v` (optional) estimate volume
- `-a` (optional) estimate surface area using our improved method
- `-s` (optional) estimate surface area using our original shell method
- `-z` (optional) display a visualization of the Monte Carlo points
- `-n <rand points>` number of random points to generate
- `-q <num query>` number of nearest neighbors to look up in kd tree
- `-V <known volume>` (optional) known volume of protein
- `-A <known surface area>` (optional) known surface area of protein
- `-f <filepath>` path to file

### Specifics
data file: must be in format:
1. First line: number of rows
2. Rest of File: x-axis y-axis z-axis radius
