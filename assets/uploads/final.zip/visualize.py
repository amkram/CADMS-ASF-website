import matplotlib.pyplot as plot


def visualize_protein(prot):
    bbox = prot.bbox

    # Visualize based on a manageable number of points
    rand_points = bbox.gen_points(prot.N)
    num_hits, inds = prot.hits_vol(rand_points)

    fig, axes = plot.subplots(ncols=1, nrows=1, subplot_kw=dict(projection='3d'))

    ax = axes

    goodx = []
    goody = []
    goodz = []
    badx = []
    bady = []
    badz = []

    max_points_visualize = 50000
    num_points_visualize = min(len(rand_points), max_points_visualize)
    # Don't visualize more than 50000 points

    for i in range(num_points_visualize):
        x = rand_points[i][0]
        y = rand_points[i][1]
        z = rand_points[i][2]

        if i in inds:
            goodx.append(x)
            goody.append(y)
            goodz.append(z)
        else:
            badx.append(x)
            bady.append(y)
            badz.append(z)

    ax.scatter(goodx, goody, goodz, color='blue', s=0.8)
    ax.scatter(badx, bady, badz, color='grey', s=0.2, alpha=0.1)

    plot.show()
