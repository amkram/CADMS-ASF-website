import time
import matplotlib.pyplot as plt
from protein_estimation import Protein


def main():

    errs = []
    times = []
    Ns = [1000 + 1000*x for x in range(100)]
    qs = [2,3,4,5,6,7,8,9,10]
    prot = Protein('data.txt', q=10, N=Ns[0])
    errs = []
    for N in Ns:
        prot.N = N
        prot.q = 10
        start = time.time()
        est, err = prot.get_volume()
        end = time.time()
        runtime = end - start
        errs.append(err)
        times.append(runtime)

    plt.figure(1)
    plt.plot(Ns, errs, 'g')

    timepolot = plt.figure(2)

    plt.plot(Ns, times, 'b-')
    plt.show()

    es = []
    for q in qs:
        prot.q = q
        prot.N = 10000
        sume = 0
        for _ in range(30):
            est, err = prot.get_volume()
            e = abs(35490.34 - est)
            sume += e
        es.append(sume/30)
    plt.figure(1)
    plt.bar(qs, es, align='center')

main()
