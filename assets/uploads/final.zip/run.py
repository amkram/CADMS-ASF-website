from protein_estimation import Protein
from visualize import visualize_protein
import argparse

# run.py -- user interface for protein estimator.
# Example usage:
#
#             python run.py -vaz -n 10000 -q 10 -V 35490.34 -f data.txt
#
# (verbose)   python run.py --volume --area --visualize --npoints 1000 --qneighbors 10
#                    --realvol 35490.34 --atoms data.txt
#
# will estimate the volume and surface area (-v, -a) and plot the resulting points (-z)
# using 10000 random points and 10 nearest neighbors. The known volume -V is supplied (optional)

parser = argparse.ArgumentParser(
        description='Estimates the volume or surface area of a protein.',
        formatter_class=argparse.RawDescriptionHelpFormatter)
parser.add_argument('--atoms', '-f', required=True, type=str,
                    help='The path to the atom file.')
parser.add_argument('--volume', '-v', required=False, action='store_true',
                    help='If present, estimate the volume of the protein.')
parser.add_argument('--area', '-a', required=False, action='store_true',
                    help='If present, estimate the surface area of the protein using the improved method.')
parser.add_argument('--area_shell', '-s', required=False, action='store_true',
                    help='If present, estimate the surface area using our intial shell method.')
parser.add_argument('--npoints', '-n', required=False, type=int, default=10000,
                    help='The number of Monte Carlo points to generate.')
parser.add_argument('--qneighbors', '-q', required=False, type=int, default=10,
                    help='The estimator will search the q nearest atoms to each random point.')
parser.add_argument('--visualize', '-z', required=False, action='store_true',
                    help='If present, the estimator will display a plot of the random points.')
parser.add_argument('--realvol', '-V', required=False, type=float,
                    help='If present, the estimator will report the true error in volume.')
parser.add_argument('--realarea', '-A', required=False, type=float,
                    help='If present, the estimator will report the true error in surface area.')
arg = parser.parse_args()


def main():
    if not arg.volume and not arg.area and not arg.area_shell and not arg.visualize:
        print('You must supply at least one of -v, -a, -z, -s')
        return
    N = arg.npoints
    q = arg.qneighbors
    prot = Protein(atomfile=arg.atoms, q=q, N=N)
    if arg.volume:
        print('========= Volume =========')
        print(f'Estimating volume using {N} points and {q} nearest neighbors...')
        est, err = prot.get_volume()
        print('Estimate:', est, 'A^3')
        print('Estimated error:', err, 'A^3')
        if arg.realvol:
            print('True (absolute) error:', abs(arg.realvol - est), ' A^3')
    if arg.area_shell:
        print('====== Surface Area (Shell Method) ======')
        print(f'Estimating surface area using {N} points and {q} nearest neighbors...')
        est, err = prot.get_area()
        print('Estimate:', est, 'A^2')
        print('Estimated error:', err, 'A^2')
        if arg.realarea:
            print('True (absolute) error:', abs(arg.realarea - est), ' A^2')
    if arg.area:
        print('====== Surface Area (Improved Method) ======')
        print(f'Estimating surface area using {N} points and {q} nearest neighbors...')
        est, err = prot.alt_get_area()
        print('Estimate:', est, 'A^2')
        print('Estimated error:', err, 'A^2')
        if arg.realarea:
            print('True (absolute) error:', abs(arg.realarea - est), ' A^2')
    if arg.visualize:
        print('====== Creating plot ======')
        visualize_protein(prot)


main()
